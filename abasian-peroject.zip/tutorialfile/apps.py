from django.apps import AppConfig


class TutorialfileConfig(AppConfig):
    name = 'tutorialfile'
    verbose_name="فایل های آموزشی"