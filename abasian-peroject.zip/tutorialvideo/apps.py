from django.apps import AppConfig


class TutorialvideoConfig(AppConfig):
    name = 'tutorialvideo'
    verbose_name="ویدیو های آموزشی"
