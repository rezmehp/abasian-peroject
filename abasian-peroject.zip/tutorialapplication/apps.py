from django.apps import AppConfig


class TutorialapplicationConfig(AppConfig):
    name = 'tutorialapplication'
    verbose_name="نرم افزارهای آموزشی"