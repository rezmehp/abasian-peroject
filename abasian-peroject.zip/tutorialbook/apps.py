from django.apps import AppConfig


class TutorialbookConfig(AppConfig):
    name = 'tutorialbook'
    verbose_name="کتاب های آموزشی"