from django.apps import AppConfig


class TutorialvoiceConfig(AppConfig):
    name = 'tutorialvoice'
    verbose_name="صوت های آموزشی"